import React from 'react'

export const Header = () => {
  return (
    <h2>
      Story Poker
    </h2>
  )
}
